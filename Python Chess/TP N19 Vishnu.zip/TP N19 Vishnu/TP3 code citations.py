"""
Code citations

Animation "Run" function from https://www.cs.cmu.edu/~112-n19/notes/notes-animations-part2.html



Chess pieces:
https://commons.wikimedia.org/wiki/Category:PNG_chess_pieces/Standard_transparent
Stored in "chess_pieces" folder inside TP3 Vishnu


"""