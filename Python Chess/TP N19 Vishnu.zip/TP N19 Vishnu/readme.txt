Unzip the file ‘TP3 Vishnu’. 
It contains:
	-This readme file
	-Design and documentation
	-Project codebase
	-Folder containing chess piece images
	-Link to video demo

Run the file ‘TP3_final.py’. It opens a game of chess, which can be played according to the conventional rules.

Thank you!
				
				